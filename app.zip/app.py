from flask import Flask, request, jsonify, session
import google.generativeai as genai
from dotenv import load_dotenv
import os
from db import init_db, register_user, login_user

app = Flask(__name__)
app.secret_key = '090564f3c22f412d3b4294107f1a0242'

load_dotenv()
init_db()
gemini_api_key = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=gemini_api_key)

def ask_gemini(conversational_text, summary_text):
    generation_config = {
        "temperature": 1,
        "top_p": 0.95,
        "top_k": 64,
        "max_output_tokens": 1000,
        "response_mime_type": "text/plain",
    }

    model = genai.GenerativeModel(
        model_name="gemini-1.5-flash",
        generation_config=generation_config,
    )

    chat_session = model.start_chat(
        history=[]
    )
    prompt = f"""
        Analyze the provided summary of a conversation between a Customer and an Agent. 

        1. Respond with "Yes" if the summary contains hallucinated information, or "No" if it is accurate.
        2. If "Yes", list only the hallucinated claims and their reasons.

        Conversation:
        {conversational_text}

        Summary:
        {summary_text}
    """
    response = chat_session.send_message(prompt)
    print(response)
    return response

def detect_hallucination(conversational_text, summary_text, threshold=0.7):
    ask_gemini(conversational_text, summary_text)

@app.route('/api/detect_hallucination', methods=['POST'])
def detect_hallucination_api():
    data = request.json
    conversation = data.get('conversational_text')
    summary = data.get('summary')

    if not conversation or not summary:
        return jsonify({"error": "Both conversation and summary are required"}), 400

    detect_hallucination(conversation, summary)
    hallucination = "No"
    similarity = 1
    return jsonify({
        "hallucination_detected": hallucination,
        "similarity_score": similarity
    })

@app.route('/api/register', methods=['POST'])
def register_api():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400
    
    if register_user(email, password):
        return jsonify({"message": "User registered successfully."}), 201
    else:
        return jsonify({"error": "Email already exists."}), 409

@app.route('/api/login', methods=['POST'])
def login_api():
    data = request.json
    email = data.get('email')
    password = data.get('password')
    
    if not email or not password:
        return jsonify({"error": "Email and password are required."}), 400
    
    if login_user(email, password):
        session['user'] = email
        return jsonify({"message": "Login successful."}), 200
    else:
        return jsonify({"error": "Invalid email or password."}), 401

@app.route('/api/logout', methods=['POST'])
def logout_api():
    session.pop('user', None)
    return jsonify({"message": "Logout successful."}), 200

if __name__ == '__main__':
    app.run(debug=True)