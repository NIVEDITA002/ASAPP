import pandas as pd
import requests

df = pd.read_csv('Hackathon_Oct_2024 - Sheet2.csv')

df.drop(columns=['response', 'answer'], inplace=True)

grouped_df = df.groupby('conversation_id').agg({
    'speaker': lambda x: list(x),
    'text': lambda x: list(x),
    'summary_a': 'first'
}).reset_index()

conversation_map = {}
summary_map = {}

for index, row in grouped_df.iterrows():
    conversation_id = row['conversation_id']
    speakers = row['speaker']
    conversations = row['text']
    summary = row['summary_a']
    conversation = ""
    for idx in range(len(speakers)):
        if speakers[idx] == "SENDER_CUSTOMER":
            speaker = "Customer"
        else:
            speaker = "Agent"
        conversation += f"{speaker}: {conversations[idx]}\n"

    conversation_map[conversation_id] = conversation
    summary_map[conversation_id] = summary

id = "01J4HXCTFHD7J91N7T6KBCHM5D"
conversation = conversation_map[id]
summary = summary_map[id]

prompt = f"""
Analyze the provided summary of a conversation between a Customer and an Agent. 

1. Respond with "Yes" if the summary contains hallucinated information, or "No" if it is accurate.
2. If "Yes," list only the hallucinated claims and their reasons.

Conversation:
{conversation}

Summary:
{summary}
"""

response = requests.post(
  "https://api.cohere.com/v2/chat",
  headers={
    "Authorization": "Bearer U4H6zDyTeLjiEw0mvXIsbiJAiDeZyWqCAJfJfAVW",
    "Content-Type": "application/json"
  },
  json={
    "model": "command-r",
    "messages": [
      {
        "role": "user",
        "content": f"{prompt}"
      }
    ],
    "stream": False
  },
)

print(response.json()["message"]["content"][0]["text"])