import os
import google.generativeai as genai
import pandas as pd
from dotenv import load_dotenv

load_dotenv()
gemini_api_key = os.getenv("GEMINI_API_KEY")
genai.configure(api_key=gemini_api_key)

df = pd.read_csv('Hackathon_Oct_2024 - Sheet2.csv')
df.drop(columns=['response', 'answer'], inplace=True)
grouped_df = df.groupby('conversation_id').agg({
    'speaker': lambda x: list(x),
    'text': lambda x: list(x),
    'summary_a': 'first'
}).reset_index()

conversation_map = {}
summary_map = {}

for index, row in grouped_df.iterrows():
    conversation_id = row['conversation_id']
    speakers = row['speaker']
    conversations = row['text']
    summary = row['summary_a']
    conversation = ""
    for idx in range(len(speakers)):
        if speakers[idx] == "SENDER_CUSTOMER":
            speaker = "Customer"
        else:
            speaker = "Agent"
        conversation += f"{speaker}: {conversations[idx]}\n"

    conversation_map[conversation_id] = conversation
    summary_map[conversation_id] = summary

id = "01J396J3BM06E7J8WXA80FYSCG"
conversation = conversation_map[id]
summary = summary_map[id]

generation_config = {
  "temperature": 0.5,
  "top_p": 0.95,
  "top_k": 64,
  "max_output_tokens": 500,
  "response_mime_type": "text/plain",
}

# model= genai.GenerativeModel(model_name="gemini-pro",generation_config=generation_config) 

model = genai.GenerativeModel(
  model_name="gemini-1.5-flash",
  generation_config=generation_config,
)

chat_session = model.start_chat(history=[])

prompt = f"""
Please analyze the following conversation and its summary. Follow these steps:

Step 1: Extract distinct claims from the summary.
Step 2: Compare each claim with the conversation to verify if it is factually correct or can be inferred. Only flag a claim as hallucinated if it:
  - Introduces details that are factually incorrect,
  - Introduces details that are not present,
  - Introduces details that cannot be inferred from the conversation.

Do not flag claims that reflect suggestions or possibilities mentioned by the agent.

Format your response as follows:

Hallucination: Yes or No
If No, just respond No
If Yes, list each hallucinated claim and reason in the following format:
  - Claim: [claim]
  - Reason: [reason]

If hallucinations are present, rewrite the summary to correct inaccuracies while maintaining the original style and word count. Format the corrected summary as follows:
Corrected Summary: [rewritten summary]

Conversation:
{conversation}

Summary:
{summary}
"""

response = chat_session.send_message(prompt)
print(response.text)