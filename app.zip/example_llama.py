import pandas as pd
from langchain_ollama import OllamaLLM
from langchain_core.prompts import ChatPromptTemplate

df = pd.read_csv('Hackathon_Oct_2024 - Sheet2.csv')

df.drop(columns=['response', 'answer'], inplace=True)

grouped_df = df.groupby('conversation_id').agg({
    'speaker': lambda x: list(x),
    'text': lambda x: list(x),
    'summary_a': 'first'
}).reset_index()

conversation_map = {}
summary_map = {}

for index, row in grouped_df.iterrows():
    conversation_id = row['conversation_id']
    speakers = row['speaker']
    conversations = row['text']
    summary = row['summary_a']
    conversation = ""
    for idx in range(len(speakers)):
        if speakers[idx] == "SENDER_CUSTOMER":
            speaker = "Customer"
        else:
            speaker = "Agent"
        conversation += f"{speaker}: {conversations[idx]}\n"
    
    conversation_map[conversation_id] = conversation
    summary_map[conversation_id] = summary

id = "01J4HXCTFHD7J91N7T6KBCHM5D"
conversation = conversation_map[id]
summary = summary_map[id]

model = OllamaLLM(model="llama3")

template = f"""
Please analyze the following conversation and its summary. Follow these steps:

Step 1: Extract distinct claims from the summary.
Step 2: Compare each claim with the conversation to verify if it is factually correct or can be inferred. Only flag a claim as hallucinated if it:
  - Introduces details that are factually incorrect,
  - Introduces details that are not present,
  - Introduces details that cannot be inferred from the conversation.

Do not flag claims that reflect suggestions or possibilities mentioned by the agent.

Format your response as follows:

Hallucination: Yes or No
If No, just respond No
If Yes, list each hallucinated claim and reason in the following format:
  - Claim: [claim]
  - Reason: [reason]

If hallucinations are present, rewrite the summary to correct inaccuracies while maintaining the original style and word count. Format the corrected summary as follows:
Corrected Summary: [rewritten summary]

Conversation:
{conversation}

Summary:
{summary}
"""

prompt = ChatPromptTemplate.from_template(template)
chain = prompt | model
print(conversation, summary, "\n")
result = chain.invoke({"conversation":conversation, "summary": summary})
print(result)